# MoonSec V3 backend

`.msd <url|text>` accepts attachments and replied files too. `.do` routes the
MoonSec V3 banner here. V2 and unmatched V3 layouts are not promised supported.
The pipeline is MoonsecDeobfuscator → Lua 5.1 bytecode → unluac → Luau syntax
validation → the single `-- deobfuscated by kfc` header and existing raw-link delivery.
It does not run recovered scripts or substitute an execution trace for source.

Dependencies, built locally:

- .NET 9 runtime and SDK for building `../deobfuscator/upstream/moonsec-v3`.
- Java 8+ runtime (or `MOONSEC_JAVA` pointing to its executable); a portable
  Temurin 17 JDK is in `../deobfuscator/runtime-java` on this Windows checkout.
- Build `unluac` from `../deobfuscator/upstream/unluac/src` using javac, then
  package its classes as `build/unluac.jar` with main class `unluac.Main`.
- Existing `deobfuscator/deobf/bin/luau-ast` syntax validator.

MoonSec build: `dotnet build deobfuscator/upstream/moonsec-v3 -c Release`.
Java build (from allthing, with javac/jar on PATH):

    javac -encoding UTF-8 --release 8 -sourcepath deobfuscator/upstream/unluac/src -d deobfuscator/upstream/unluac/build/classes deobfuscator/upstream/unluac/src/unluac/Main.java
    jar --create --file deobfuscator/upstream/unluac/build/unluac.jar --main-class unluac.Main -C deobfuscator/upstream/unluac/build/classes .

On hosted Linux, install the .NET runtime and Java, build the two backends and
the existing Luau validator there. This change does not deploy them to Wispbyte.
Stage timeouts share one 300-second budget; Java uses a 512 MB heap limit.

## Provenance and local changes

- [tupsutumppu/MoonsecDeobfuscator](https://github.com/tupsutumppu/MoonsecDeobfuscator)
  pinned at `2afe5d8a97333433de33b99efe0f9d420f7b9e6f`, GPL-3.0.
  Its original LICENSE and complete source remain in the upstream directory.
  Local changes add closed-expression validation before NLua evaluates keys,
  disable the Lua/.NET bridge and add a validation self-test. Only local numeric,
  boolean and closure computations with local assignments/returns/conditionals
  are allowed. Unsupported globals, indexing, loops and external writes fail.
- [viruscamp/unluac](https://github.com/viruscamp/unluac) pinned at
  `9c59af46483a932a47224bf2ac84ad8a63094da5`, MIT; original source and license retained.

Regression: `py -3 -m unittest moonsec.test_runner deobfuscator.test_commands`.
The stored V3 sample is decoded and parsed only, never executed or fetched onward.

Readable output normalizes unluac registers with scope-aware binding identities,
splits bounded straight-line versions without splitting captured cells or losing
branch-merge state, and shares Aqua's alias/method/configuration cleanup. Naming
uses API roles and UI usage (`keySystem`, `options`, `httpResponse`, etc.) rather
than original source names, which are not present in stripped bytecode. Fixed-width
multiple returns are retained where dropping extra arguments would change behavior.
Shared cleanup preserves parenthesized-call statement boundaries and handles
repeat-loop variable writes before evaluating the loop condition. Meaningful
names are scoped to bindings, so registers in unrelated functions do not share
an accidental inferred name. Literal private configuration writes fold into
table constructors without rewriting globals or their setters.
Offline fixture regressions: `node obf/node_modules/tsx/dist/cli.mjs moonsec/test-readable.ts`.

The bytecode exporter preserves explicit return values and appends a missing
unreachable implicit return for unluac compatibility, recursively in prototypes.
The local unluac build initializes stripped-register bindings before resolving
child closures, avoiding unresolved `_UPVALUE` placeholders. Bounded acyclic
forward-goto merges are lowered to Luau-compatible control flow before validation;
unsupported goto shapes fail explicitly. Validation remains enabled, and failure
messages preserve the exception cause rather than only the end of a stack trace.

Register-frame sizing uses Lua 5.1 operand semantics, not only the largest A
operand. This includes SELF's implicit A+1, call arguments/results, loop slots,
LOADNIL ranges and source registers; constant/upvalue/prototype indices do not
inflate the frame. Serialization enforces a minimum two-slot frame and rejects
out-of-range register operands instead of wrapping the byte-sized stack count.
The nested SELF regression checks unluac output and executes only a handwritten
method/self fixture, never an obfuscated payload.

Open-result CALL chains now retain their bytecode-defined argument count instead
of padding/truncating to the stack's register count. Fixed-width calls still keep
their explicit width and nil holes. Readability cleanup separates register
lifetimes before the first observing closure, retains declarations needed by later
writes, and checks that rewritten aliases do not lose their producers. Generated
unbound registers are rejected instead of being delivered as accidental globals.
UI method calls/configuration literals and service names are recovered where
their usage is unambiguous; original stripped variable names cannot be recovered.

Cleanup also folds private iterator triples into native generic-for headers and
removes adjacent argument/property-write temporaries when evaluation order is
preserved. Loop-carried cells, captured state, escaping iterator variables and
mutable object snapshots remain explicit. These are AST/binding-based rules,
not replacements for a particular game ID, URL, property or sample.
