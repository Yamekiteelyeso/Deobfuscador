import {readableParser} from '../ad/lift/readable-parser.js';
import {analyzeBindings,captureBoundaries} from '../ad/lift/bindings.js';
import {cleanupReadable} from '../ad/lift/cleanup.js';
import {finalizeReadableNames} from '../ad/lift/names.js';
import {simplifyRegisters} from '../ad/lift/presentation.js';
import {lowerForwardGotos} from './control-flow.js';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';

export function readableMoonsec(source:string):string {
  source=lowerForwardGotos(source);
  const tree=readableParser.parse(source,{ranges:true,scope:true,luaVersion:'5.3',encodingMode:'x-user-defined'});
  const originalGlobals=new Set<string>((tree.globals??[]).map((n:any)=>n.name));
  const bindings=analyzeBindings(tree),nodes:any[]=[],pending=[tree];
  while(pending.length){const node=pending.pop();if(!node?.type)continue;nodes.push(node);
    for(const [key,value] of Object.entries(node)){if(['range','loc','comments','globals'].includes(key))continue;
      if(Array.isArray(value))pending.push(...value.filter(v=>v?.type));else if((value as any)?.type)pending.push(value);
    }
  }
  const used=new Set(nodes.filter(n=>n.type==='Identifier').map(n=>n.name)),names=new Map<any,string>();let serial=0;
  for(const node of nodes){if(node.type!=='Identifier'||!/^L\d+_\d+$/.test(node.name))continue;
    const binding=bindings.get(node);if(!binding||names.has(binding))continue;
    let name:string;do{name=`value_${++serial}`;}while(used.has(name));names.set(binding,name);used.add(name);
  }
  const edits=nodes.filter(n=>n.type==='Identifier'&&names.has(bindings.get(n))).map(n=>({start:n.range[0],end:n.range[1],text:names.get(bindings.get(n))!}));
  const pieces:string[]=[];let cursor=0;
  for(const edit of edits.sort((a,b)=>a.start-b.start)){pieces.push(source.slice(cursor,edit.start),edit.text);cursor=edit.end;}
  pieces.push(source.slice(cursor));
  const cleaned=cleanupReadable(splitStraightLineVersions(simplifyRegisters(pieces.join(''))));
  const checked=readableParser.parse(cleaned,{ranges:true,luaVersion:'5.3'}),checkedBindings=analyzeBindings(checked);
  function validate(n:any){
    if(n.type==='Identifier'&&/^value_\d+$/.test(n.name)&&!checkedBindings.get(n)&&!originalGlobals.has(n.name))throw new Error(`Cleanup introduced an unbound register: ${n.name}`);
    for(const [key,value] of Object.entries(n)){
      if(['range','loc','comments','globals'].includes(key)||n.type==='MemberExpression'&&key==='identifier'||n.type==='TableKeyString'&&key==='key')continue;
      if(Array.isArray(value))value.filter(v=>v?.type).forEach(validate);else if((value as any)?.type)validate(value);
    }
  }validate(checked);
  return finalizeReadableNames(cleaned);
}

// Separate short-lived unluac register versions before a control-flow merge.
// Captured cells and writes inside branches/loops remain shared and untouched.
export function splitStraightLineVersions(source:string):string {
  const tree=readableParser.parse(source,{ranges:true,luaVersion:'5.3',encodingMode:'x-user-defined'});
  const bindings=analyzeBindings(tree),used=new Set<string>(),edits:{start:number,end:number,text:string}[]=[];
  const captures=captureBoundaries(tree,bindings);
  const kids=(n:any):any[]=>Object.entries(n).flatMap(([k,v]:any)=>['range','loc','comments'].includes(k)?[]:Array.isArray(v)?v.filter(x=>x?.type):v?.type?[v]:[]);
  function collect(n:any){if(n.type==='Identifier')used.add(n.name);for(const child of kids(n))collect(child);}collect(tree);
  let serial=0;
  function fresh(){let name:string;do{name=`value_${++serial}`;}while(used.has(name));used.add(name);return name;}
  function reference(n:any,env:Map<any,string>){
    if(n.type==='FunctionDeclaration'){if(n.identifier)reference(n.identifier,env);const child=new Map(env);
      for(const parameter of n.parameters)if(/^value_\d+$/.test(parameter.name))child.set(bindings.get(parameter),parameter.name);
      body(n.body,child);return;}
    if(n.type==='Identifier'){const name=env.get(bindings.get(n));if(name)edits.push({start:n.range[0],end:n.range[1],text:name});return;}
    for(const child of kids(n))reference(child,env);
  }
  function reads(n:any,binding:any):boolean {
    if(n.type==='Identifier')return bindings.get(n)===binding;
    if(['AssignmentStatement','LocalStatement'].includes(n.type))return n.init.some((x:any)=>reads(x,binding))||n.variables.filter((x:any)=>x.type!=='Identifier').some((x:any)=>reads(x,binding));
    return kids(n).some(child=>reads(child,binding));
  }
  function incomingNeeded(statements:any[],binding:any):boolean {
    for(let i=0;i<statements.length;i++){
      const s=statements[i];
      if(['AssignmentStatement','LocalStatement'].includes(s.type)){
        if(reads(s,binding))return true;
        if(s.variables.some((v:any)=>v.type==='Identifier'&&bindings.get(v)===binding))return false;
      }else if(s.type==='IfStatement'){
        if(s.clauses.some((c:any)=>c.condition&&reads(c.condition,binding)))return true;
        const rest=statements.slice(i+1);
        return s.clauses.some((c:any)=>incomingNeeded([...c.body,...rest],binding))||
          !s.clauses.some((c:any)=>!c.condition)&&incomingNeeded(rest,binding);
      }else if(s.type==='RepeatStatement'){
        // A repeat body runs before its condition; an unconditional first write
        // kills the incoming register value. Other loop forms stay conservative.
        for(const entry of s.body){if(reads(entry,binding))return true;
          if(['AssignmentStatement','LocalStatement'].includes(entry.type)&&entry.variables.some((v:any)=>v.type==='Identifier'&&bindings.get(v)===binding))return false;
          if(!['AssignmentStatement','LocalStatement','CallStatement'].includes(entry.type))break;
        }
        if(reads(s,binding))return true;
      }else if(reads(s,binding))return true;
    }
    return false;
  }
  function body(statements:any[],env:Map<any,string>,protectedCells=new Set<any>(),budget={remaining:160}){
    let prefix=true,versions=0;
    const locals=statements.filter(s=>s.type==='LocalStatement').reduce((n,s)=>n+s.variables.length,0);
    budget.remaining=Math.min(budget.remaining,Math.max(0,180-locals));
    if(locals>=100)budget.remaining=0;
    for(const [position,statement] of statements.entries()){
      if(['IfStatement','RepeatStatement'].includes(statement.type)&&budget.remaining>0&&locals<100){
        const reset:string[]=[];
        for(const [binding] of env)if(budget.remaining>0&&!protectedCells.has(binding)&&!binding.captured&&!incomingNeeded(statements.slice(position),binding)){
          const name=fresh();env.set(binding,name);reset.push(name);
          budget.remaining--;
        }
        if(reset.length)edits.push({start:statement.range[0],end:statement.range[0],text:'local '+reset.join(', ')+'\n'});
      }
      if(['IfStatement','WhileStatement','RepeatStatement','ForNumericStatement','ForGenericStatement','DoStatement','ReturnStatement'].includes(statement.type))prefix=false;
      const split=prefix&&locals<100&&statement.type==='AssignmentStatement'&&statement.variables.length<=budget.remaining&&statement.variables.every((v:any)=>
        v.type==='Identifier'&&/^value_\d+$/.test(v.name)&&bindings.get(v)&&
        (!bindings.get(v)!.captured||v.range[0]<(captures.get(bindings.get(v))??0))&&!protectedCells.has(bindings.get(v)));
      if(split){
        for(const expression of statement.init)reference(expression,env);
        for(const variable of statement.variables){const name=fresh();env.set(bindings.get(variable),name);edits.push({start:variable.range[0],end:variable.range[1],text:name});}
        edits.push({start:statement.range[0],end:statement.range[0],text:'local '});versions++;budget.remaining-=statement.variables.length;
      }else if(statement.type==='FunctionDeclaration'&&!statement.isLocal&&statement.identifier?.type==='Identifier'&&budget.remaining>0){
        const variable=statement.identifier,binding=bindings.get(variable);
        if(binding&&!protectedCells.has(binding)&&(!binding.captured||variable.range[0]<(captures.get(binding)??0))){
          const name=fresh();env.set(binding,name);budget.remaining--;
          edits.push({start:statement.range[0],end:statement.range[0],text:'local '});
        }
        reference(statement,env);
      }else if(statement.type==='IfStatement'){
        const preserve=new Set(protectedCells),rest=statements.slice(position+1);
        for(const [binding] of env)if(incomingNeeded(rest,binding))preserve.add(binding);
        for(const clause of statement.clauses){if(clause.condition)reference(clause.condition,env);body(clause.body,new Map(env),preserve,budget);}
      }else if(['WhileStatement','RepeatStatement','ForNumericStatement','ForGenericStatement'].includes(statement.type)){
        const preserve=new Set(protectedCells),rest=statements.slice(position+1),inner=new Map(env);
        for(const [binding] of env)if(binding.captured||incomingNeeded(rest,binding)||incomingNeeded(statement.body,binding)||
          statement.condition&&reads(statement.condition,binding))preserve.add(binding);
        const headers=statement.iterators??[statement.start,statement.end,statement.step].filter(Boolean);
        for(const header of headers)reference(header,env);
        if(statement.type!=='RepeatStatement'&&statement.condition)reference(statement.condition,env);
        for(const variable of statement.variables??[statement.variable].filter(Boolean))
          if(/^value_\d+$/.test(variable.name))inner.set(bindings.get(variable),variable.name);
        body(statement.body,inner,preserve,budget);
        if(statement.type==='RepeatStatement')reference(statement.condition,inner);
      }else reference(statement,env);
      if(statement.type==='LocalStatement')for(const variable of statement.variables)
        if(/^value_\d+$/.test(variable.name)&&!env.has(bindings.get(variable)))env.set(bindings.get(variable),variable.name);
      if(['IfStatement','WhileStatement','RepeatStatement','ForNumericStatement','ForGenericStatement','DoStatement'].includes(statement.type))prefix=true;
    }
  }
  body(tree.body,new Map());const pieces:string[]=[];let cursor=0;
  for(const edit of edits.sort((a,b)=>a.start-b.start||a.end-b.end)){pieces.push(source.slice(cursor,edit.start),edit.text);cursor=edit.end;}
  pieces.push(source.slice(cursor));return pieces.join('');
}

if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  const [input,output]=process.argv.slice(2);if(!input||!output)throw Error('Usage: readable.ts input.lua output.lua');
  fs.writeFileSync(output,readableMoonsec(fs.readFileSync(input,'utf8')),'utf8');
}
