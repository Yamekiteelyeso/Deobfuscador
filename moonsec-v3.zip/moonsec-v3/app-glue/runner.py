from __future__ import annotations

import asyncio
import os
import re
from pathlib import Path
import shutil
import tempfile

ROOT = Path(__file__).resolve().parent.parent


def dependencies():
    backend = ROOT / "deobfuscator/upstream/moonsec-v3/bin/Release/net9.0/MoonsecDeobfuscator.dll"
    jar = ROOT / "deobfuscator/upstream/unluac/build/unluac.jar"
    dotnet = shutil.which("dotnet")
    java = os.environ.get("MOONSEC_JAVA") or shutil.which("java")
    if not java:
        suffix = "java.exe" if os.name == "nt" else "java"
        java = next((str(p) for p in (ROOT / "deobfuscator/runtime-java").glob(f"*/bin/{suffix}")), None)
    for name, value in (("dotnet", dotnet), ("Java", java), ("MoonSec backend", backend), ("unluac", jar)):
        if not value or (isinstance(value, Path) and not value.is_file()):
            raise RuntimeError(f"Missing {name}; see moonsec/README.md setup instructions")
    syntax = ROOT / "deobfuscator/deobf/bin" / ("luau-ast.exe" if os.name == "nt" else "luau-ast")
    if not syntax.is_file():
        raise RuntimeError("Missing Luau syntax validator")
    return str(dotnet), str(java), backend, jar, syntax


async def run_moonsec(source: str, timeout: float = 300):
    if not re.search(r"protected (?:with|using) MoonSec V3\b", source[:1000], re.I):
        raise ValueError("Not detected as MoonSec V3; this backend does not support MoonSec V2")
    dotnet, java, backend, jar, syntax = dependencies()
    directory = Path(tempfile.mkdtemp(prefix="luaenvlog_msd_"))
    process = None
    deadline = asyncio.get_running_loop().time() + timeout
    async def stage(*args):
        nonlocal process
        process = await asyncio.create_subprocess_exec(*map(str, args), cwd=str(ROOT),
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        stdout, stderr = await asyncio.wait_for(process.communicate(), max(0, deadline - asyncio.get_running_loop().time()))
        if process.returncode:
            diagnostic = (stderr or stdout).decode("utf-8", "replace").strip()
            # The exception message precedes Java's stack frames; keep the cause.
            raise RuntimeError("MoonSec V3 failed: " + diagnostic[:1200])
        return stdout, stderr
    try:
        input_file, bytecode, output = (directory / name for name in ("input.lua", "recovered.luac", "deobfuscated.lua"))
        input_file.write_text(source, encoding="utf-8")
        await stage(dotnet, backend, "-dev", "-i", input_file, "-o", bytecode)
        if not bytecode.is_file() or bytecode.read_bytes()[:5] != b"\x1bLua\x51":
            raise RuntimeError("MoonSec backend did not produce Lua 5.1 bytecode")
        await stage(java, "-Xmx512m", "-jar", jar, "--nodebug", "-o", output, bytecode)
        if not output.is_file() or not output.read_text(encoding="utf-8").strip():
            raise RuntimeError("MoonSec source decompiler produced no output")
        node = shutil.which("node")
        if not node:
            raise RuntimeError("Missing Node.js for MoonSec readable cleanup")
        await stage(node, ROOT / "obf/node_modules/tsx/dist/cli.mjs", ROOT / "moonsec/readable.ts", output, output)
        await stage(syntax, output)
        from paste_upload import logged_deobfuscation
        output.write_text(logged_deobfuscation(output.read_text(encoding="utf-8")), encoding="utf-8")
        return output, {"clean": True, "status": "MoonSec V3 deobfuscated", "backend": "moonsec-v3-unluac"}
    except BaseException as error:
        if process is not None and process.returncode is None:
            if os.name == "nt":
                killer = await asyncio.create_subprocess_exec("taskkill", "/PID", str(process.pid), "/T", "/F",
                    stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
                await killer.wait()
            else:
                process.kill()
            await process.communicate()
        shutil.rmtree(directory, ignore_errors=True)
        if isinstance(error, asyncio.TimeoutError):
            raise RuntimeError(f"MoonSec V3 timed out ({timeout:g}s)") from error
        raise
