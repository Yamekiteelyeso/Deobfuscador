import {readableParser} from '../ad/lift/readable-parser.js';

// unluac emits Lua 5.3 forward gotos for some Lua 5.1 short-circuit merges.
// Lower only a bounded acyclic region with no scope declarations or loop exits.
export function lowerForwardGotos(source:string):string {
  const tree=readableParser.parse(source,{ranges:true,luaVersion:'5.3',encodingMode:'x-user-defined'});
  const edits:{start:number,end:number,text:string}[]=[];
  const kids=(n:any):any[]=>Object.entries(n).flatMap(([k,v]:any)=>['range','loc','comments','globals'].includes(k)?[]:Array.isArray(v)?v.filter(x=>x?.type):v?.type?[v]:[]);
  const jumps:any[]=[];function scan(n:any){if(n.type==='GotoStatement')jumps.push(n);for(const child of kids(n))scan(child);}scan(tree);
  const handled=new Set<any>();
  function process(body:any[]){
    for(let end=0;end<body.length;end++){
      const label=body[end];if(label.type!=='LabelStatement')continue;
      const candidates=jumps.filter(j=>j.label.name===label.label.name&&j.range[0]<label.range[0]);
      if(candidates.length!==1)continue;
      const jump=candidates[0],start=body.findIndex(s=>s.range[0]<=jump.range[0]&&s.range[1]>=jump.range[1]);
      if(start<0||start>=end)continue;
      let valid=true;function check(n:any){
        if(n.type==='FunctionDeclaration'){valid=false;return;}
        if(n.type.endsWith('Statement')&&!['IfStatement','AssignmentStatement','CallStatement','GotoStatement'].includes(n.type))valid=false;
        if(n.type==='GotoStatement'&&n!==jump)valid=false;
        for(const child of kids(n))check(child);
      }
      body.slice(start,end).forEach(check);if(!valid)continue;
      edits.push({start:body[start].range[0],end:body[start].range[0],text:'repeat\n'},
        {start:jump.range[0],end:jump.range[1],text:'do break end'},
        {start:label.range[0],end:label.range[1],text:'until true'});
      handled.add(jump);
    }
  }
  function visit(n:any){if(Array.isArray(n.body))process(n.body);for(const child of kids(n))visit(child);}visit(tree);
  if(jumps.some(j=>!handled.has(j)))throw new Error('Unsupported MoonSec goto control flow; refusing to drop a branch');
  let result=source;for(const edit of edits.sort((a,b)=>b.start-a.start||b.end-a.end))result=result.slice(0,edit.start)+edit.text+result.slice(edit.end);
  return result;
}
