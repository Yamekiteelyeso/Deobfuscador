MOONSEC V3 DEOBFUSCATOR — extracted from "logged by kfc" 1.0.5
===============================================================

Recovered by static analysis on 2026-10-18. Nothing was executed.

Provenance
----------
logged-by-kfc-1.0.5-setup.exe (sha256 430f95f0…f743)
  -> install-core.exe          (NSIS 3.04, sha256 d919bd97…73cc)
     -> resources/engines/engines.pack  (AES-256-GCM, key shipped in app.asar)
        1,137 files, every per-file sha256 verified OK
     -> resources/engines/native/…      (plaintext, merged in at runtime)

IMPORTANT — how this zip was assembled
--------------------------------------
The product splits each backend across TWO locations:

  * engines.pack (encrypted)  -> source/config/managed assets
  * engines/native (plaintext)-> compiled binaries

At startup `engine-pack.cjs` `mount()` decrypts the pack into a temp dir and
then copies `native/` into it, throwing "Duplicate engine file" on any
collision. I verified the two MoonSec sets have ZERO filename overlap, then
merged them the same way. That is why `bin/Release/net9.0/` here is complete
while neither half was on its own: the `.exe`/`.dll` come from `native/`, but
`MoonsecDeobfuscator.deps.json` and `.runtimeconfig.json` only exist in the
encrypted pack. Without the merge the binary will not launch.


Upstream
--------
https://github.com/tupsutumppu/MoonsecDeobfuscator   — GPL-3.0
Target: Lua scripts protected with **MoonSec V3**.
V2 and unmatched V3 layouts are explicitly NOT supported (runner.py rejects
input unless it matches /protected (?:with|using) MoonSec V3\b/ in the first
1000 chars).


Contents
--------
source/                       85 files, 672 KB
    The complete GPL-3.0 C# project.
    ├── LICENSE                          GPL-3.0 full text
    ├── MoonsecDeobfuscator.csproj       net9.0, Exe, nullable+implicit usings
    │                                    PackageRefs: Antlr4.Runtime.Standard
    │                                    4.13.1, NLua 1.7.6, QuikGraph 2.5.0
    ├── MoonsecDeobfuscator.sln
    ├── README.md                        upstream usage + worked example
    ├── MoonSec-build-and-local-changes.md   vendor's build notes + local diff
    └── src/
        ├── Program.cs                   CLI entry
        ├── Deobfuscation/
        │   ├── Deobfuscator.cs, BytecodeDeobfuscator.cs, Context.cs,
        │   │   OpCodes.cs, ClosedKeyExpression.cs
        │   ├── Bytecode/                Deserializer, Serializer, Disassembler,
        │   │                            StackSize, Models/{Constant,Function,
        │   │                            Instruction,OpCode,OpType}.cs
        │   ├── Rewriters/               ConstantFolder, ConstantReplacer,
        │   │                            ControlFlowSolver, HandlerRewriter
        │   ├── Walkers/                 Analyzer, FingerprintGenerator,
        │   │                            Renamer, StringCollector
        │   └── Utils/                   Extensions, Matching, StringDecoding,
        │                                TreeSolver
        └── Syntax/
            ├── Grammar/Lua.g4           ANTLR4 Lua grammar
            ├── Parser/                  LuaLexer, LuaParser, LuaBaseVisitor,
            │                            LuaVisitor  (ANTLR-generated)
            ├── Ast/                     full Lua AST: 14 Expressions,
            │                            15 Statements, Literals, Node,
            │                            NodeList, ParameterList, PrettyPrinter
            │   └── Visitors/            AstWalker, AstRewriter, Order,
            │                            Pre/PostOrderRewriteDispatch,
            │                            IRewriteDispatch
            ├── Semantic/                SymbolTable, SymbolTableBuilder,
            │                            VariableInfo
            └── CstToAstVisitor.cs

bin/Release/net9.0/           45 files, 11 MB
    The compiled build, merged as described above.
    ├── MoonsecDeobfuscator.exe   156 KB   ← run this
    ├── MoonsecDeobfuscator.dll   207 KB
    ├── MoonsecDeobfuscator.deps.json / .runtimeconfig.json  (from the pack)
    ├── Antlr4.Runtime.Standard.dll 192K · NLua.dll 93K · KeraLua.dll 31K
    │   QuikGraph.dll 385K
    ├── MSVC runtimes (msvcp140*, vcruntime140*, vccorlib140, concrt140)
    └── runtimes/{win-x64,win-x86,win-arm,win-arm64,linux-x64,linux-arm64,
                  osx,android-*,ios,maccatalyst,tvos}/native/lua54.*
        (NuGet native Lua 5.4 assets for every RID — only your own is used)

deps/unluac/
    ├── unluac.jar              303 KB   stage 2 of the pipeline, prebuilt
    └── source/                 134 .java files (MIT) — to rebuild the jar

deps/luau-bin/                  5.2 MB
    luau-ast.exe (830 KB), luau.exe (1.4 MB), luau-compile.exe (1.2 MB)
    + MSVC runtimes. Final syntax/compile validation stage.

app-glue/                       5 files, 32 KB
    How "logged by kfc" actually drives this backend — NOT part of upstream.
    ├── runner.py          4.1 KB  the orchestrator (see pipeline below)
    ├── readable.ts        11 KB   post-decompile readability cleanup
    ├── control-flow.ts    2.3 KB
    ├── README.md          5.6 KB
    └── __init__.py


The pipeline (from app-glue/runner.py)
--------------------------------------
    input.lua
      │  1. dotnet MoonsecDeobfuscator.dll -dev -i input.lua -o recovered.luac
      │     -> Lua 5.1 bytecode; runner asserts magic == b"\x1bLua\x51"
      │  2. java -Xmx512m -jar unluac.jar --nodebug -o deobfuscated.lua recovered.luac
      │  3. node tsx moonsec/readable.ts deobfuscated.lua deobfuscated.lua
      │  4. luau-ast deobfuscated.lua          (syntax validation only)
      │  5. prepend the "-- deobfuscated by kfc" banner
      ▼
    deobfuscated.lua

One shared 300 s budget across all stages. Java capped at a 512 MB heap.
Note stage 1 emits **Lua 5.1 bytecode**, not source — MoonSec's VM is
devirtualised first, then unluac does the actual decompilation.

CLI flags (from source/README.md):
    -dev -i <in> -o <out>    devirtualize, dump bytecode
    -dis -i <in> -o <out>    devirtualize, dump bytecode disassembly


Running it
----------
The .NET binary needs the **.NET 9 runtime** (not bundled here; the product
ships one at engines/native/runtime/dotnet, ~180 MB).

    dotnet bin/Release/net9.0/MoonsecDeobfuscator.dll -dev -i script.lua -o out.luac

Or build from source:

    dotnet build source -c Release

Then continue with unluac (any Java 8+; the product bundles a Temurin JRE at
engines/native/deobfuscator/runtime-java, 17 MB, not included here):

    java -Xmx512m -jar deps/unluac/unluac.jar --nodebug -o out.lua out.luac

To rebuild unluac.jar from deps/unluac/source:

    javac -encoding UTF-8 --release 8 -sourcepath deps/unluac/source \
      -d classes deps/unluac/source/unluac/Main.java
    jar --create --file unluac.jar --main-class unluac.Main -C classes .


Notes
-----
- runner.py does `from paste_upload import logged_deobfuscation` — that imports
  a LOCAL string helper which only prepends the banner. It does NOT upload
  anything. (`upload_paste`, the function in that module that talks to
  veryrich.online, is never called anywhere in the product.)
- No network code in the MoonSec C# source; `MoonsecDeobfuscator.dll` contains
  no HTTP client references at all.
- The vendor's own doc is explicit: "It does not run recovered scripts or
  substitute an execution trace for source."
- luau-ast/luau/luau-compile are unsigned local builds of Roblox's Luau;
  everything else signed is Microsoft/Oracle redistributable.
