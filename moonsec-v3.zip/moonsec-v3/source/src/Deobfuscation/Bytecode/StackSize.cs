using MoonsecDeobfuscator.Bytecode.Models;

namespace MoonsecDeobfuscator.Deobfuscation.Bytecode;

// Lua 5.1 operands are not all registers. In particular RK operands >= 256
// are constants, and A in comparisons is a boolean, not a destination.
public static class StackSize
{
    public static byte Required(Function function)
    {
        var size = Math.Max(2, (int) function.NumParams);
        void Register(int register)
        {
            if (register < 0 || register >= 255)
                throw new InvalidOperationException($"Invalid Lua 5.1 register {register}");
            size = Math.Max(size, register + 1);
        }
        void RK(int operand)
        {
            if (operand < 256) Register(operand);
        }
        foreach (var i in function.Instructions)
        {
            switch (i.OpCode)
            {
                case OpCode.Jmp: break;
                case OpCode.Eq: case OpCode.Lt: case OpCode.Le:
                    RK(i.B); RK(i.C); break;
                case OpCode.Return:
                    if (i.B != 1) Register(i.A + Math.Max(0, i.B - 2));
                    break;
                case OpCode.Move: case OpCode.Unm: case OpCode.Not:
                case OpCode.Len: case OpCode.TestSet:
                    Register(i.A); Register(i.B); break;
                case OpCode.LoadNil:
                    Register(i.A); Register(i.B); break;
                case OpCode.GetTable:
                    Register(i.A); Register(i.B); RK(i.C); break;
                case OpCode.SetTable:
                    Register(i.A); RK(i.B); RK(i.C); break;
                case OpCode.Self:
                    Register(i.A + 1); Register(i.B); RK(i.C); break;
                case OpCode.Add: case OpCode.Sub: case OpCode.Mul:
                case OpCode.Div: case OpCode.Mod: case OpCode.Pow:
                    Register(i.A); RK(i.B); RK(i.C); break;
                case OpCode.Concat:
                    Register(i.A); Register(i.B); Register(i.C); break;
                case OpCode.Call: case OpCode.TailCall:
                    Register(i.A + Math.Max(0, i.B - 1));
                    if (i.OpCode == OpCode.Call && i.C > 1) Register(i.A + i.C - 2);
                    break;
                case OpCode.ForLoop: case OpCode.ForPrep:
                    Register(i.A + 3); break;
                case OpCode.TForLoop:
                    Register(i.A + Math.Max(3, 2 + i.C)); break;
                case OpCode.SetList:
                    Register(i.A + i.B); break;
                case OpCode.VarArg:
                    Register(i.A + Math.Max(0, i.B - 2)); break;
                case OpCode.LoadK: case OpCode.LoadBool: case OpCode.GetUpval:
                case OpCode.GetGlobal: case OpCode.SetGlobal: case OpCode.SetUpval:
                case OpCode.NewTable: case OpCode.Test: case OpCode.Close:
                case OpCode.Closure:
                    Register(i.A); break;
                default:
                    throw new InvalidOperationException($"Cannot size unknown opcode {i.OpCode}");
            }
        }
        return (byte) size;
    }
}
