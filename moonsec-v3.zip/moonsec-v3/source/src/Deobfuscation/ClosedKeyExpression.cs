using MoonsecDeobfuscator.Ast;
using MoonsecDeobfuscator.Ast.Expressions;
using MoonsecDeobfuscator.Ast.Literals;
using MoonsecDeobfuscator.Ast.Statements;

namespace MoonsecDeobfuscator.Deobfuscation;

// Local integration hardening: only closed arithmetic/closure computations may
// reach NLua. No globals, indexing, external calls, loops or property writes.
internal static class ClosedKeyExpression
{
    public static void Validate(Expression root)
    {
        var budget = 100000;
        Expression(root, [], 0);
        void Tick(int depth)
        {
            if (--budget < 0 || depth > 256) throw new InvalidOperationException("MoonSec key expression exceeds validation limits");
        }
        void Expression(Expression node, HashSet<string> scope, int depth)
        {
            Tick(depth);
            switch (node)
            {
                case NumberLiteral or BooleanLiteral or Nil: return;
                case Name name when scope.Contains(name.Value): return;
                case BinaryExpression binary when binary.Operator != BinaryOperator.Concat:
                    Expression(binary.Left, scope, depth + 1); Expression(binary.Right, scope, depth + 1); return;
                case UnaryExpression unary when unary.Operator != UnaryOperator.Length:
                    Expression(unary.Operand, scope, depth + 1); return;
                case Call call:
                    Expression(call.Function, scope, depth + 1);
                    foreach (var argument in call.Arguments) Expression(argument, scope, depth + 1);
                    return;
                case AnonymousFunction function:
                    var child = new HashSet<string>(scope);
                    foreach (var name in function.Parameters.Names) child.Add(name.Value);
                    Block(function.Body, child, depth + 1); return;
                default: throw new InvalidOperationException("Unsupported or non-local MoonSec key expression");
            }
        }
        void Block(Block block, HashSet<string> scope, int depth)
        {
            Tick(depth);
            foreach (var statement in block.Statements)
            {
                switch (statement)
                {
                    case LocalDeclare declaration:
                        foreach (var value in declaration.Values) Expression(value, scope, depth + 1);
                        foreach (var name in declaration.Names) scope.Add(name.Value);
                        break;
                    case Assign assignment:
                        foreach (var target in assignment.Variables)
                            if (target is not Name name || !scope.Contains(name.Value)) throw new InvalidOperationException("Non-local MoonSec key write rejected");
                        foreach (var value in assignment.Values) Expression(value, scope, depth + 1);
                        break;
                    case Return returns:
                        foreach (var value in returns.Values) Expression(value, scope, depth + 1);
                        break;
                    case ExpressionStatement call when call.Expression is Call:
                        Expression(call.Expression, scope, depth + 1); break;
                    case If conditional:
                        Expression(conditional.IfClause.Condition, scope, depth + 1);
                        Block(conditional.IfClause.Body, new(scope), depth + 1);
                        foreach (var clause in conditional.ElseIfClauses)
                        { Expression(clause.Condition, scope, depth + 1); Block(clause.Body, new(scope), depth + 1); }
                        if (conditional.ElseBody != null) Block(conditional.ElseBody, new(scope), depth + 1);
                        break;
                    default: throw new InvalidOperationException("Unsupported MoonSec key statement");
                }
            }
        }
    }
}
