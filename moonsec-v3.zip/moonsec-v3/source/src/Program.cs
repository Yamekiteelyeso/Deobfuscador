﻿using MoonsecDeobfuscator.Deobfuscation;
using MoonsecDeobfuscator.Deobfuscation.Bytecode;
using MoonsecDeobfuscator.Ast;
using MoonsecDeobfuscator.Ast.Statements;

namespace MoonsecDeobfuscator;

public static class Program
{
    /*
        Devirtualize and dump bytecode to file:
            -dev -i <path to input> -o <path to output>

        Devirtualize and dump bytecode disassembly to file:
            -dis -i <path to input> -o <path to output>
    */

    static void Main(string[] args)
    {
        if (args is ["--self-test-stack-bytecode", var stackFixturePath])
        {
            var child = new MoonsecDeobfuscator.Bytecode.Models.Function
            {
                MaxStackSize = 1, Functions = [],
                Constants = [new MoonsecDeobfuscator.Bytecode.Models.StringConstant("object"),
                    new MoonsecDeobfuscator.Bytecode.Models.StringConstant("method")],
                Instructions = [
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.GetGlobal, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Self, A = 0, B = 0, C = 257 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, A = 0, B = 3 }]
            };
            var root = new MoonsecDeobfuscator.Bytecode.Models.Function
            {
                MaxStackSize = 1, Functions = [child], Constants = [],
                Instructions = [
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Closure, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, A = 0, B = 2 }]
            };
            // These operands must increase the frame; constants, upvalue and
            // prototype indices must not. Open calls have no fixed result limit.
            void Check(MoonsecDeobfuscator.Bytecode.Models.OpCode opcode, int a, int b, int c, int expected)
            {
                var probe = new MoonsecDeobfuscator.Bytecode.Models.Function
                {
                    Instructions = [new() { OpCode = opcode, A = a, B = b, C = c }]
                };
                if (StackSize.Required(probe) != expected)
                    throw new InvalidOperationException($"Incorrect stack size for {opcode}");
            }
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Self, 0, 0, 257, 2);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Call, 0, 6, 9, 8);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Call, 0, 0, 0, 2);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadNil, 0, 7, 0, 8);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Move, 0, 8, 0, 9);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.ForLoop, 0, 99, 0, 4);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.TForLoop, 0, 0, 3, 6);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.VarArg, 0, 8, 0, 7);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.SetList, 0, 7, 999, 8);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Eq, 1, 256, 257, 2);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.GetUpval, 0, 200, 0, 2);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadK, 0, 10000, 0, 2);
            Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, 0, 8, 0, 7);
            var rejected = false;
            try { Check(MoonsecDeobfuscator.Bytecode.Models.OpCode.Self, 254, 0, 256, 0); }
            catch (InvalidOperationException error) when (error.Message.StartsWith("Invalid Lua")) { rejected = true; }
            if (!rejected) throw new InvalidOperationException("Oversized register frame accepted");
            using var stream = new FileStream(stackFixturePath, FileMode.Create, FileAccess.Write);
            using var serializer = new Serializer(stream);
            serializer.Serialize(root);
            return;
        }
        if (args is ["--self-test-open-bytecode", var openFixturePath])
        {
            var root = new MoonsecDeobfuscator.Bytecode.Models.Function
            {
                MaxStackSize = 4, Functions = [],
                Constants = [new MoonsecDeobfuscator.Bytecode.Models.StringConstant("collector"), new MoonsecDeobfuscator.Bytecode.Models.StringConstant("producer")],
                Instructions = [
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.GetGlobal, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.GetGlobal, A = 1, B = 1 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Call, A = 1, B = 1, C = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Call, A = 0, B = 0, C = 2 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, A = 0, B = 2 }]
            };
            using var stream = new FileStream(openFixturePath, FileMode.Create, FileAccess.Write);
            using var serializer = new Serializer(stream);
            serializer.Serialize(root);
            return;
        }
        if (args is ["--self-test-return-bytecode", var fixturePath])
        {
            var child = new MoonsecDeobfuscator.Bytecode.Models.Function
            {
                MaxStackSize = 3, NumUpvalues = 1, Functions = [],
                Constants = [new MoonsecDeobfuscator.Bytecode.Models.NumberConstant(23)],
                Instructions = [
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Jmp, B = 1 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadNil, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.GetUpval, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadNil, A = 1, B = 1 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadK, A = 2, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, A = 0, B = 4 }]
            };
            var root = new MoonsecDeobfuscator.Bytecode.Models.Function
            {
                MaxStackSize = 2, Functions = [child],
                Constants = [new MoonsecDeobfuscator.Bytecode.Models.NumberConstant(42)],
                Instructions = [
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.LoadK, A = 1, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Closure, A = 0, B = 0 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Move, A = 0, B = 1 },
                    new() { OpCode = MoonsecDeobfuscator.Bytecode.Models.OpCode.Return, A = 0, B = 2 }]
            };
            using var stream = new FileStream(fixturePath, FileMode.Create, FileAccess.Write);
            using var serializer = new Serializer(stream);
            serializer.Serialize(root);
            if (root.Instructions.Count != 4 || child.Instructions.Count != 6)
                throw new InvalidOperationException("Serialization mutated the instruction lists");
            return;
        }
        if (args is ["--self-test-keys"])
        {
            foreach (var expression in new[] { "1+2", "(function() local n=1;return n+2 end)()" })
                ClosedKeyExpression.Validate(((Return)Block.FromString("return " + expression).Statements[0]).Values[0]);
            foreach (var expression in new[] { "os.execute('no')", "luanet.import_type('System.IO.File')", "(function() external=1;return 1 end)()", "(function() while true do end end)()" })
            {
                var rejected = false;
                try { ClosedKeyExpression.Validate(((Return)Block.FromString("return " + expression).Statements[0]).Values[0]); }
                catch (InvalidOperationException) { rejected = true; }
                if (!rejected) throw new InvalidOperationException("Unsafe key expression accepted");
            }
            Console.WriteLine("Closed key-expression validation passed");
            return;
        }
        if (args.Length != 5 || args[1] != "-i" || args[3] != "-o")
        {
            Console.WriteLine("Usage:");
            Console.WriteLine("Devirtualize and dump bytecode to file:\n\t-dev -i <input> -o <output>");
            Console.WriteLine("Devirtualize and dump bytecode disassembly to file:\n\t-dis -i <input> -o <output>");
            return;
        }

        var command = args[0];
        var input = args[2];
        var output = args[4];

        if (!File.Exists(input))
        {
            Console.WriteLine("Invalid input path!");
            return;
        }

        if (command == "-dev")
        {
            var result = new Deobfuscator().Deobfuscate(File.ReadAllText(input));
            using var stream = new FileStream(output, FileMode.Create, FileAccess.Write);
            using var serializer = new Serializer(stream);

            serializer.Serialize(result);
        }
        else if (command == "-dis")
        {
            var result = new Deobfuscator().Deobfuscate(File.ReadAllText(input));
            File.WriteAllText(output, new Disassembler(result).Disassemble());
        }
        else
        {
            Console.WriteLine("Invalid command!");
        }
    }
}
